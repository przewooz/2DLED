#pragma once

namespace cec14
{
	void cec14_test_func(double *, double *, int, int, int);

	/*double *OShift, *M, *y, *z, *x_bound;
	int ini_flag = 0, n_flag, func_flag, *SS;*/
}
